'use client'

import { useEffect, useState, useCallback } from 'react'

export interface ScanHistoryItem {
  id: string
  content: string
  type: 'url' | 'text' | 'email' | 'phone' | 'wifi' | 'sms' | 'vcard' | 'geo' | 'unknown'
  timestamp: number
  source: 'camera' | 'image'
}

const STORAGE_KEY = 'qr-nexus-history-v1'
const MAX_HISTORY = 50

function detectType(content: string): ScanHistoryItem['type'] {
  const trimmed = content.trim()
  if (/^https?:\/\//i.test(trimmed)) return 'url'
  if (/^mailto:/i.test(trimmed)) return 'email'
  if (/^tel:/i.test(trimmed)) return 'phone'
  if (/^sms:/i.test(trimmed) || /^smsto:/i.test(trimmed)) return 'sms'
  if (/^wifi:/i.test(trimmed)) return 'wifi'
  if (/^begin:vcard/i.test(trimmed) || /^vcard:/i.test(trimmed)) return 'vcard'
  if (/^geo:/i.test(trimmed)) return 'geo'
  if (/^[a-zA-Z][\w-]*@[a-zA-Z0-9-]+\.[a-zA-Z]{2,}/.test(trimmed)) return 'email'
  return 'unknown'
}

export function useHistory() {
  const [history, setHistory] = useState<ScanHistoryItem[]>([])
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    try {
      const raw = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEY) : null
      if (raw) {
        const parsed = JSON.parse(raw) as ScanHistoryItem[]
        if (Array.isArray(parsed)) {
          setHistory(parsed.slice(0, MAX_HISTORY))
        }
      }
    } catch {
      // ignore
    } finally {
      setLoaded(true)
    }
  }, [])

  useEffect(() => {
    if (!loaded) return
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(history.slice(0, MAX_HISTORY)))
    } catch {
      // ignore
    }
  }, [history, loaded])

  const addEntry = useCallback((content: string, source: 'camera' | 'image') => {
    if (!content) return null
    const item: ScanHistoryItem = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
      content,
      type: detectType(content),
      timestamp: Date.now(),
      source,
    }
    setHistory((prev) => {
      // Avoid duplicates (same content within last minute)
      const recent = prev[0]
      if (recent && recent.content === content && Date.now() - recent.timestamp < 60_000) {
        return prev
      }
      const next = [item, ...prev].slice(0, MAX_HISTORY)
      return next
    })
    return item
  }, [])

  const removeEntry = useCallback((id: string) => {
    setHistory((prev) => prev.filter((it) => it.id !== id))
  }, [])

  const clearAll = useCallback(() => {
    setHistory([])
  }, [])

  return { history, addEntry, removeEntry, clearAll, loaded }
}

export function detectContentType(content: string): ScanHistoryItem['type'] {
  return detectType(content)
}
