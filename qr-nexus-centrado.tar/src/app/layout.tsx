import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "QR.NEXUS — Escáner de códigos QR",
  description:
    "QR.NEXUS es un escáner de códigos QR rápido y privado. Escanea con la cámara o subiendo una imagen. Sin registro, sin rastreo, funciona directamente en tu navegador.",
  keywords: [
    "escáner QR",
    "lector QR",
    "código QR",
    "escanear QR",
    "QR.NEXUS",
  ],
  authors: [{ name: "QR.NEXUS" }],
  icons: {
    icon: "/favicon.svg",
  },
  openGraph: {
    title: "QR.NEXUS — Escáner de códigos QR",
    description:
      "Escáner de códigos QR rápido y privado. Cámara o imagen, todo desde tu navegador.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "QR.NEXUS — Escáner de códigos QR",
    description:
      "Escáner de códigos QR rápido y privado. Cámara o imagen, todo desde tu navegador.",
  },
};

export const viewport: Viewport = {
  themeColor: "#1E4C8A",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
