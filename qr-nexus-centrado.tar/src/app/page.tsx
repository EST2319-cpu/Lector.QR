'use client'

import { useState, useCallback } from 'react'
import { Camera, Image as ImageIcon, Power, ShieldCheck, Zap, Github, Cloud } from 'lucide-react'
import { CameraScanner } from '@/components/qr/camera-scanner'
import { ImageScanner } from '@/components/qr/image-scanner'
import { ResultPanel } from '@/components/qr/result-panel'
import { HistoryPanel } from '@/components/qr/history-panel'
import { useHistory, type ScanHistoryItem } from '@/hooks/use-qr-history'
import { useToast } from '@/hooks/use-toast'

type Mode = 'camera' | 'image'

export default function Home() {
  const [mode, setMode] = useState<Mode>('camera')
  const [cameraActive, setCameraActive] = useState(false)
  const [currentItem, setCurrentItem] = useState<ScanHistoryItem | null>(null)
  const { history, addEntry, removeEntry, clearAll } = useHistory()
  const { toast } = useToast()

  const handleScan = useCallback((content: string) => {
    const item = addEntry(content, mode === 'camera' ? 'camera' : 'image')
    if (item) {
      setCurrentItem(item)
      toast({
        title: 'QR detectado',
        description: 'Contenido capturado correctamente.',
        duration: 1800,
      })
    }
  }, [addEntry, mode, toast])

  const handleSelectHistory = (item: ScanHistoryItem) => {
    setCurrentItem(item)
  }

  const handleClearResult = () => {
    setCurrentItem(null)
  }

  return (
    <div className="relative min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/95 backdrop-blur-sm sticky top-0 z-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-md bg-[var(--brand)] flex items-center justify-center">
              <ScanFrameIcon />
            </div>
            <div className="leading-none">
              <h1 className="text-base sm:text-lg font-semibold tracking-tight text-foreground">
                QR.NEXUS
              </h1>
              <p className="text-xs text-muted-foreground mt-0.5 hidden sm:block">
                Lector de códigos QR
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-full border border-border bg-secondary">
              <span className="h-1.5 w-1.5 rounded-full bg-[var(--brand)]" />
              <span className="text-xs text-muted-foreground">Disponible</span>
            </div>
            <a
              href="https://nextjs.org/docs"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center gap-1.5 rounded-md border border-border bg-secondary px-2.5 py-1.5 text-xs text-muted-foreground hover:text-foreground hover:border-[var(--brand)]/40 transition"
            >
              <Github className="h-3.5 w-3.5" />
              Docs
            </a>
          </div>
        </div>
      </header>

      {/* Hero / Tagline */}
      <section className="mx-auto max-w-7xl w-full px-4 sm:px-6 pt-10 pb-6 text-center">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border border-border bg-secondary mb-4 animate-fade-in-up">
          <ShieldCheck className="h-3.5 w-3.5 text-[var(--brand)]" />
          <span className="text-xs text-muted-foreground">
            Privado · funciona directamente en tu navegador
          </span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-semibold tracking-tight text-foreground animate-fade-in-up">
          Escáner de códigos QR
        </h2>
        <p className="mt-2 text-sm text-muted-foreground max-w-xl mx-auto animate-fade-in-up">
          Lee cualquier código QR al instante con tu cámara o subiendo una imagen. Rápido, seguro y fácil de usar.
        </p>
      </section>

      {/* Main content */}
      <main className="mx-auto max-w-7xl w-full px-4 sm:px-6 pb-8 flex-1">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-6">

          {/* Left: Scanner */}
          <div className="lg:col-span-2 card-elevated rounded-lg p-4 sm:p-5">
            {/* Mode toggle */}
            <div className="flex items-center gap-1 p-1 rounded-lg bg-secondary border border-border w-full sm:w-auto mx-auto sm:inline-flex mb-4">
              <button
                onClick={() => setMode('camera')}
                className={`flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition ${
                  mode === 'camera'
                    ? 'bg-[var(--brand)] text-white shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Camera className="h-4 w-4" />
                <span>Cámara</span>
              </button>
              <button
                onClick={() => setMode('image')}
                className={`flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition ${
                  mode === 'image'
                    ? 'bg-[var(--brand)] text-white shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <ImageIcon className="h-4 w-4" />
                <span>Imagen</span>
              </button>
            </div>

            {/* Scanner area */}
            <div className="max-w-md mx-auto">
              {mode === 'camera' ? (
                <div className="space-y-3">
                  <CameraScanner onScan={handleScan} active={cameraActive} />
                  <button
                    onClick={() => setCameraActive((v) => !v)}
                    className={`w-full inline-flex items-center justify-center gap-2 rounded-md px-4 py-2.5 text-sm font-semibold transition ${
                      cameraActive
                        ? 'border border-destructive/40 bg-destructive/10 text-destructive hover:bg-destructive/15'
                        : 'border border-[var(--brand)] bg-[var(--brand)] text-white hover:bg-[var(--brand-soft)]'
                    }`}
                  >
                    <Power className="h-4 w-4" />
                    {cameraActive ? 'Detener cámara' : 'Activar cámara'}
                  </button>
                </div>
              ) : (
                <ImageScanner onScan={handleScan} />
              )}
            </div>

            {/* Feature row */}
            <div className="mt-5 max-w-md mx-auto grid grid-cols-3 gap-2 sm:gap-3 text-center">
              <FeatureBadge icon={<Zap className="h-4 w-4" />} title="Instantáneo" />
              <FeatureBadge icon={<ShieldCheck className="h-4 w-4" />} title="Privado" />
              <FeatureBadge icon={<Cloud className="h-4 w-4" />} title="Sin registro" />
            </div>
          </div>

          {/* Right: Result */}
          <div className="card-elevated rounded-lg flex flex-col">
            <div className="px-4 py-3 border-b border-border flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-[var(--brand)]" />
              <h3 className="text-sm font-medium text-foreground">
                Resultado
              </h3>
            </div>
            <ResultPanel item={currentItem} onClear={handleClearResult} />
          </div>
        </div>

        {/* History panel (full width below) */}
        <div className="mt-4 lg:mt-6 card-elevated rounded-lg">
          <div className="px-4 py-3 border-b border-border flex items-center justify-between">
            <div className="flex items-center gap-2">
              <HistoryIcon className="h-4 w-4 text-[var(--brand)]" />
              <h3 className="text-sm font-medium text-foreground">
                Historial de escaneos
              </h3>
            </div>
            <span className="text-xs text-muted-foreground">Guardado solo en tu dispositivo</span>
          </div>
          <HistoryPanel
            items={history}
            onSelect={handleSelectHistory}
            onRemove={removeEntry}
            onClear={clearAll}
            selectedItem={currentItem}
          />
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-border bg-card">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-muted-foreground">
          <p>
            © {new Date().getFullYear()} QR.NEXUS
          </p>
          <p>
            Hecho con Next.js · html5-qrcode · jsQR
          </p>
        </div>
      </footer>
    </div>
  )
}

function FeatureBadge({ icon, title }: { icon: React.ReactNode; title: string }) {
  return (
    <div className="flex flex-col items-center gap-1.5 p-2 rounded-md border border-border bg-secondary/60">
      <span className="text-[var(--brand)]">{icon}</span>
      <span className="text-xs text-muted-foreground">{title}</span>
    </div>
  )
}

function ScanFrameIcon() {
  return (
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" className="text-white">
      <path d="M4 7V4h3M17 4h3v3M20 17v3h-3M7 20H4v-3M9 4h6M4 9v6" />
    </svg>
  )
}

function HistoryIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" className={className}>
      <path d="M3 12a9 9 0 1 0 9-9M3 12l3-3M3 12l3 3" />
      <path d="M12 7v5l3 2" />
    </svg>
  )
}
