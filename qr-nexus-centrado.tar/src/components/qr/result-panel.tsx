'use client'

import { useState } from 'react'
import {
  Link2, Copy, Check, ExternalLink, Mail, Phone, MessageSquare,
  Wifi, MapPin, FileText, Trash2, ScanLine, Info
} from 'lucide-react'
import type { ScanHistoryItem } from '@/hooks/use-qr-history'

interface ResultPanelProps {
  item: ScanHistoryItem | null
  onClear: () => void
}

const TYPE_LABELS: Record<ScanHistoryItem['type'], string> = {
  url: 'URL / Enlace',
  text: 'Texto',
  email: 'Correo',
  phone: 'Teléfono',
  sms: 'SMS',
  wifi: 'WiFi',
  vcard: 'vCard',
  geo: 'Ubicación',
  unknown: 'Contenido',
}

const TYPE_ICONS: Record<ScanHistoryItem['type'], typeof Link2> = {
  url: Link2,
  text: FileText,
  email: Mail,
  phone: Phone,
  sms: MessageSquare,
  wifi: Wifi,
  vcard: FileText,
  geo: MapPin,
  unknown: ScanLine,
}

function parseWifi(content: string): { ssid?: string; password?: string; encryption?: string } | null {
  // WIFI:T:WPA;S:mynetwork;P:mypass;;
  const m = content.match(/^wifi:/i)
  if (!m) return null
  const rest = content.slice(5)
  const result: { ssid?: string; password?: string; encryption?: string } = {}
  const t = /T:([^;]*)/i.exec(rest)
  const s = /S:([^;]*)/i.exec(rest)
  const p = /P:([^;]*)/i.exec(rest)
  if (t) result.encryption = t[1] || 'nopass'
  if (s) result.ssid = s[1]
  if (p) result.password = p[1]
  return result
}

export function ResultPanel({ item, onClear }: ResultPanelProps) {
  const [copied, setCopied] = useState(false)

  if (!item) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 p-6 text-center min-h-[260px]">
        <div className="p-3 rounded-full bg-secondary border border-border">
          <Info className="h-6 w-6 text-muted-foreground" />
        </div>
        <p className="text-sm font-medium text-foreground">Sin resultados todavía</p>
        <p className="text-xs text-muted-foreground max-w-[280px]">
          Escanea un código QR con la cámara o sube una imagen para ver aquí su contenido.
        </p>
      </div>
    )
  }

  const Icon = TYPE_ICONS[item.type]
  const isUrl = item.type === 'url'
  const isEmail = item.type === 'email'
  const isPhone = item.type === 'phone'
  const isSms = item.type === 'sms'
  const isWifi = item.type === 'wifi'
  const isGeo = item.type === 'geo'

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(item.content)
      setCopied(true)
      setTimeout(() => setCopied(false), 1800)
    } catch {
      // ignore
    }
  }

  const handleClear = () => {
    setCopied(false)
    onClear()
  }

  const wifi = isWifi ? parseWifi(item.content) : null
  const coords = isGeo ? item.content.replace(/^geo:/i, '').split(',').slice(0, 2).join(',') : null

  const primaryAction = isUrl
    ? { label: 'Abrir enlace', href: item.content, external: true }
    : isEmail
    ? { label: 'Enviar correo', href: item.content.startsWith('mailto:') ? item.content : `mailto:${item.content}`, external: true }
    : isPhone
    ? { label: 'Llamar', href: item.content.startsWith('tel:') ? item.content : `tel:${item.content.replace(/[^+\d]/g, '')}`, external: true }
    : isSms
    ? { label: 'Enviar SMS', href: item.content, external: true }
    : isGeo
    ? { label: 'Ver en mapas', href: `https://www.google.com/maps?q=${encodeURIComponent(coords || '')}`, external: true }
    : null

  return (
    <div className="flex h-full flex-col gap-3 p-4 min-h-[260px] animate-fade-in-up">
      {/* Header */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-md bg-[var(--brand-tint)] border border-[var(--brand)]/20">
            <Icon className="h-4 w-4 text-[var(--brand)]" />
          </div>
          <div>
            <p className="text-sm font-medium text-foreground">
              {TYPE_LABELS[item.type]}
            </p>
            <p className="text-xs text-muted-foreground">
              {new Date(item.timestamp).toLocaleString('es-ES', {
                hour: '2-digit', minute: '2-digit',
                day: '2-digit', month: '2-digit',
              })} · vía {item.source === 'camera' ? 'cámara' : 'imagen'}
            </p>
          </div>
        </div>
        <button
          onClick={handleClear}
          className="p-1.5 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition"
          title="Limpiar resultado"
        >
          <Trash2 className="h-4 w-4" />
        </button>
      </div>

      {/* Content card */}
      <div className="flex-1 rounded-md border border-border bg-secondary/50 p-3">
        <p className="text-sm text-foreground break-words whitespace-pre-wrap leading-relaxed max-h-[200px] overflow-y-auto custom-scrollbar">
          {item.content}
        </p>
      </div>

      {/* WiFi special preview */}
      {wifi && (wifi.ssid || wifi.password) && (
        <div className="rounded-md border border-border bg-secondary/50 p-3 text-xs space-y-1">
          {wifi.ssid && (
            <div className="flex justify-between gap-2">
              <span className="text-muted-foreground">Red (SSID):</span>
              <span className="text-foreground">{wifi.ssid}</span>
            </div>
          )}
          {wifi.password && (
            <div className="flex justify-between gap-2">
              <span className="text-muted-foreground">Contraseña:</span>
              <span className="text-foreground">{wifi.password}</span>
            </div>
          )}
          {wifi.encryption && (
            <div className="flex justify-between gap-2">
              <span className="text-muted-foreground">Cifrado:</span>
              <span className="text-foreground">{wifi.encryption}</span>
            </div>
          )}
        </div>
      )}

      {/* Actions */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={handleCopy}
          className="inline-flex items-center gap-1.5 rounded-md border border-border bg-secondary px-3 py-1.5 text-xs font-medium text-foreground hover:bg-accent transition"
        >
          {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
          {copied ? 'Copiado' : 'Copiar'}
        </button>

        {primaryAction && (
          <a
            href={primaryAction.href}
            target={primaryAction.external ? '_blank' : undefined}
            rel={primaryAction.external ? 'noopener noreferrer' : undefined}
            className="inline-flex items-center gap-1.5 rounded-md border border-[var(--brand)] bg-[var(--brand)] text-white px-3 py-1.5 text-xs font-semibold hover:bg-[var(--brand-soft)] transition"
          >
            <ExternalLink className="h-3.5 w-3.5" />
            {primaryAction.label}
          </a>
        )}
      </div>
    </div>
  )
}
