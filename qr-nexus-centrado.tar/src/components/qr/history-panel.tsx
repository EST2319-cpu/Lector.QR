'use client'

import {
  Link2, FileText, Mail, Phone, MessageSquare, Wifi, MapPin,
  ScanLine, Trash2, History, Eraser
} from 'lucide-react'
import type { ScanHistoryItem } from '@/hooks/use-qr-history'

interface HistoryPanelProps {
  items: ScanHistoryItem[]
  onSelect: (item: ScanHistoryItem) => void
  onRemove: (id: string) => void
  onClear: () => void
  selectedItem: ScanHistoryItem | null
}

const TYPE_ICONS: Record<ScanHistoryItem['type'], typeof Link2> = {
  url: Link2,
  text: FileText,
  email: Mail,
  phone: Phone,
  sms: MessageSquare,
  wifi: Wifi,
  vcard: FileText,
  geo: MapPin,
  unknown: ScanLine,
}

function timeAgo(ts: number): string {
  const diff = Date.now() - ts
  const sec = Math.floor(diff / 1000)
  if (sec < 60) return 'ahora'
  const min = Math.floor(sec / 60)
  if (min < 60) return `hace ${min} min`
  const hr = Math.floor(min / 60)
  if (hr < 24) return `hace ${hr} h`
  const day = Math.floor(hr / 24)
  return `hace ${day} d`
}

export function HistoryPanel({ items, onSelect, onRemove, onClear, selectedItem }: HistoryPanelProps) {
  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-2 p-8 text-center min-h-[160px]">
        <History className="h-7 w-7 text-muted-foreground/50" />
        <p className="text-sm text-muted-foreground">Historial vacío</p>
        <p className="text-xs text-muted-foreground/70 max-w-[280px]">
          Tus códigos QR escaneados aparecerán aquí. Se guardan localmente en este dispositivo, sin servidores.
        </p>
      </div>
    )
  }

  return (
    <div className="flex flex-col">
      <div className="flex items-center justify-between px-3 py-2 border-b border-border">
        <div className="flex items-center gap-2">
          <History className="h-3.5 w-3.5 text-[var(--brand)]" />
          <span className="text-xs text-muted-foreground">
            {items.length} {items.length === 1 ? 'registro' : 'registros'}
          </span>
        </div>
        <button
          onClick={onClear}
          className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-destructive transition px-2 py-1 rounded"
        >
          <Eraser className="h-3 w-3" />
          Borrar todo
        </button>
      </div>
      <div className="max-h-[400px] overflow-y-auto custom-scrollbar divide-y divide-border">
        {items.map((it) => {
          const Icon = TYPE_ICONS[it.type]
          const active = selectedItem?.id === it.id
          return (
            <div
              key={it.id}
              onClick={() => onSelect(it)}
              className={`group flex items-start gap-2 p-3 cursor-pointer transition ${
                active ? 'bg-[var(--brand-tint)]' : 'hover:bg-secondary/60'
              }`}
            >
              <div className={`mt-0.5 p-1 rounded shrink-0 border ${active ? 'bg-[var(--brand-tint-strong)] border-[var(--brand)]/40' : 'bg-secondary border-border'}`}>
                <Icon className={`h-3.5 w-3.5 ${active ? 'text-[var(--brand)]' : 'text-muted-foreground'}`} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs text-foreground truncate leading-snug">
                  {it.content}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {timeAgo(it.timestamp)} · {it.source === 'camera' ? 'cámara' : 'imagen'}
                </p>
              </div>
              <button
                onClick={(e) => { e.stopPropagation(); onRemove(it.id) }}
                className="p-1 rounded text-muted-foreground/70 hover:text-destructive hover:bg-destructive/10 transition opacity-0 group-hover:opacity-100"
              >
                <Trash2 className="h-3 w-3" />
              </button>
            </div>
          )
        })}
      </div>
    </div>
  )
}
