'use client'

import { useRef, useState, useCallback } from 'react'
import jsQR from 'jsqr'
import { UploadCloud, ImageIcon, Loader2, AlertTriangle } from 'lucide-react'

interface ImageScannerProps {
  onScan: (content: string) => void
}

export function ImageScanner({ onScan }: ImageScannerProps) {
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [error, setError] = useState<string>('')
  const [loading, setLoading] = useState(false)
  const [dragOver, setDragOver] = useState(false)

  const processFile = useCallback(async (file: File) => {
    setError('')
    if (!file.type.startsWith('image/')) {
      setError('Por favor selecciona un archivo de imagen (PNG, JPG, etc.).')
      return
    }
    setLoading(true)
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader()
        reader.onload = () => resolve(reader.result as string)
        reader.onerror = () => reject(new Error('No se pudo leer el archivo.'))
        reader.readAsDataURL(file)
      })
      setPreview(dataUrl)

      // Load image and decode with jsQR
      const img = await new Promise<HTMLImageElement>((resolve, reject) => {
        const i = new Image()
        i.onload = () => resolve(i)
        i.onerror = () => reject(new Error('No se pudo cargar la imagen.'))
        i.src = dataUrl
      })

      const canvas = document.createElement('canvas')
      const maxDim = 1200
      const scale = Math.min(1, maxDim / Math.max(img.width, img.height))
      canvas.width = Math.floor(img.width * scale)
      canvas.height = Math.floor(img.height * scale)
      const ctx = canvas.getContext('2d', { willReadFrequently: true })
      if (!ctx) {
        throw new Error('No se pudo procesar la imagen.')
      }
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
      const decoded = jsQR(imageData.data, imageData.width, imageData.height, {
        inversionAttempts: 'attemptBoth',
      })

      if (decoded && decoded.data) {
        onScan(decoded.data)
      } else {
        setError('No se detectó ningún código QR en la imagen. Intenta con una imagen más nítida.')
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Error al procesar la imagen.')
    } finally {
      setLoading(false)
    }
  }, [onScan])

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) processFile(file)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
    const file = e.dataTransfer.files?.[0]
    if (file) processFile(file)
  }

  const handlePaste = useCallback((e: React.ClipboardEvent) => {
    const items = e.clipboardData?.items
    if (!items) return
    for (const item of items) {
      if (item.type.startsWith('image/')) {
        const file = item.getAsFile()
        if (file) {
          processFile(file)
          break
        }
      }
    }
  }, [processFile])

  return (
    <div className="flex flex-col gap-3" onPaste={handlePaste} tabIndex={0}>
      <div
        onClick={() => fileInputRef.current?.click()}
        onDragOver={(e) => { e.preventDefault(); setDragOver(true) }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        className={`relative aspect-square w-full cursor-pointer rounded-lg border-2 border-dashed transition flex flex-col items-center justify-center gap-3 p-6 text-center
          ${dragOver
            ? 'border-[var(--brand)] bg-[var(--brand-tint)]'
            : 'border-border bg-secondary/40 hover:border-[var(--brand)]/50 hover:bg-[var(--brand-tint)]'
          }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileInput}
          className="hidden"
        />
        {loading ? (
          <>
            <Loader2 className="h-10 w-10 text-[var(--brand)] animate-spin" />
            <p className="text-sm text-[var(--brand)]">Analizando imagen…</p>
          </>
        ) : preview ? (
          <>
            <img src={preview} alt="Vista previa" className="max-h-full max-w-full object-contain rounded-md" style={{ maxHeight: '70%' }} />
            <p className="text-xs text-muted-foreground">Clic para subir otra imagen</p>
          </>
        ) : (
          <>
            <div className="p-3 rounded-full bg-[var(--brand-tint)] border border-[var(--brand)]/20">
              <UploadCloud className="h-10 w-10 text-[var(--brand)]" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">Arrastra una imagen con QR</p>
              <p className="text-xs text-muted-foreground mt-1">o haz clic para seleccionar · también puedes pegar (Ctrl+V)</p>
            </div>
          </>
        )}
      </div>

      {error && (
        <div className="flex items-start gap-2 rounded-md border border-destructive/30 bg-destructive/10 p-3 text-xs text-destructive">
          <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <ImageIcon className="h-3.5 w-3.5" />
        <span>Formatos soportados: PNG, JPG, WebP, BMP</span>
      </div>
    </div>
  )
}
