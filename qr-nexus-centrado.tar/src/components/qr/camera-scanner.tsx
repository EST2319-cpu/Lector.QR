'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode'
import { Camera, CameraOff, RefreshCw, Loader2 } from 'lucide-react'

interface CameraScannerProps {
  onScan: (content: string) => void
  active: boolean
}

export function CameraScanner({ onScan, active }: CameraScannerProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const scannerRef = useRef<Html5Qrcode | null>(null)
  const [status, setStatus] = useState<'idle' | 'starting' | 'scanning' | 'error' | 'denied'>('idle')
  const [error, setError] = useState<string>('')
  const [cameras, setCameras] = useState<{ id: string; label: string }[]>([])
  const [selectedCamera, setSelectedCamera] = useState<string | null>(null)
  const lastScanRef = useRef<string>('')
  const lastScanTimeRef = useRef<number>(0)

  const stopScanner = useCallback(async () => {
    if (scannerRef.current) {
      try {
        if (scannerRef.current.isScanning) {
          await scannerRef.current.stop()
        }
        await scannerRef.current.clear()
      } catch {
        // ignore
      }
      scannerRef.current = null
    }
  }, [])

  const startScanner = useCallback(async (cameraId?: string) => {
    // Defer to next microtask so state updates happen outside the effect body
    await Promise.resolve()
    if (!containerRef.current) return
    setStatus('starting')
    setError('')

    try {
      await stopScanner()

      const elementId = 'qr-reader-container'
      containerRef.current.id = elementId

      const scanner = new Html5Qrcode(elementId, {
        formatsToSupport: [
          Html5QrcodeSupportedFormats.QR_CODE,
          Html5QrcodeSupportedFormats.AZTEC,
          Html5QrcodeSupportedFormats.DATA_MATRIX,
        ],
        verbose: false,
      })

      scannerRef.current = scanner

      const config = {
        fps: 10,
        qrbox: (viewWidth: number, viewHeight: number) => {
          const minDim = Math.min(viewWidth, viewHeight)
          const size = Math.floor(minDim * 0.7)
          return { width: size, height: size }
        },
        aspectRatio: 1.0,
      }

      const camId = cameraId || selectedCamera || undefined

      await scanner.start(
        camId || { facingMode: 'environment' },
        config,
        (decodedText) => {
          const now = Date.now()
          if (decodedText === lastScanRef.current && now - lastScanTimeRef.current < 1500) {
            return
          }
          lastScanRef.current = decodedText
          lastScanTimeRef.current = now
          onScan(decodedText)
        },
        () => {
          // per-frame error, ignore
        }
      )

      setStatus('scanning')
    } catch (e) {
      console.error(e)
      const msg = e instanceof Error ? e.message : String(e)
      if (/permission|denied|notallowed/i.test(msg)) {
        setStatus('denied')
        setError('Permiso de cámara denegado. Habilítalo en tu navegador.')
      } else {
        setStatus('error')
        setError('No se pudo iniciar la cámara. ' + msg)
      }
    }
  }, [onScan, selectedCamera, stopScanner])

  // Enumerate cameras when becoming active
  useEffect(() => {
    if (!active) return
    let cancelled = false

    async function enumCams() {
      try {
        const cams = await Html5Qrcode.getCameras()
        if (cancelled) return
        if (cams && cams.length > 0) {
          setCameras(cams.map((c) => ({ id: c.id, label: c.label || `Cámara ${c.id.slice(0, 6)}` })))
          const back = cams.find((c) => /back|rear|environment/i.test(c.label)) || cams[cams.length - 1]
          setSelectedCamera(back?.id || null)
        }
      } catch {
        // ignore, will use facingMode fallback
      }
    }
    enumCams()
    return () => { cancelled = true }
  }, [active])

  // Start/stop when active toggles
  useEffect(() => {
    let cancelled = false
    if (active) {
      startScanner().catch(() => {})
    } else {
      stopScanner().finally(() => {
        if (!cancelled) setStatus('idle')
      })
    }
    return () => {
      cancelled = true
      stopScanner()
    }
  }, [active, startScanner, stopScanner])

  const handleSwitchCamera = (id: string) => {
    setSelectedCamera(id)
    if (active) {
      startScanner(id)
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="relative aspect-square w-full overflow-hidden rounded-lg bg-[var(--surface-dark)] border border-border">
        {/* Scanner viewport */}
        <div ref={containerRef} className="absolute inset-0 [&>video]:h-full [&>video]:w-full [&>video]:object-cover" />

        {/* Corner markers (visible during scanning) */}
        {status === 'scanning' && (
          <>
            <div className="scanner-corner scanner-corner-tl" />
            <div className="scanner-corner scanner-corner-tr" />
            <div className="scanner-corner scanner-corner-bl" />
            <div className="scanner-corner scanner-corner-br" />
          </>
        )}

        {/* Idle / placeholder state */}
        {status === 'idle' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-center p-6">
            <Camera className="h-12 w-12 text-white/50" />
            <p className="text-sm text-white/80">Cámara apagada</p>
            <p className="text-xs text-white/50">Pulsa &quot;Activar cámara&quot; para empezar</p>
          </div>
        )}

        {/* Starting */}
        {status === 'starting' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-[var(--surface-dark)]/90">
            <Loader2 className="h-10 w-10 text-white/80 animate-spin" />
            <p className="text-sm text-white/90">Iniciando cámara…</p>
          </div>
        )}

        {/* Error */}
        {(status === 'error' || status === 'denied') && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-[var(--surface-dark)]/95 p-6 text-center">
            <CameraOff className="h-10 w-10 text-destructive" />
            <p className="text-sm font-medium text-destructive">
              {status === 'denied' ? 'Permiso denegado' : 'Error de cámara'}
            </p>
            <p className="text-xs text-white/70 max-w-xs">{error}</p>
            <button
              onClick={() => startScanner()}
              className="mt-2 inline-flex items-center gap-2 rounded-md border border-white/30 bg-white/10 px-3 py-1.5 text-xs text-white hover:bg-white/20 transition"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              Reintentar
            </button>
          </div>
        )}
      </div>

      {/* Camera selector + controls */}
      {cameras.length > 1 && status === 'scanning' && (
        <div className="flex flex-wrap gap-2">
          {cameras.map((cam) => (
            <button
              key={cam.id}
              onClick={() => handleSwitchCamera(cam.id)}
              className={`text-xs px-2.5 py-1 rounded-md border transition ${
                selectedCamera === cam.id
                  ? 'border-[var(--brand)] bg-[var(--brand-tint)] text-[var(--brand)]'
                  : 'border-border bg-secondary text-muted-foreground hover:text-foreground'
              }`}
            >
              {cam.label}
            </button>
          ))}
        </div>
      )}

      <p className="text-xs text-muted-foreground leading-relaxed">
        Apunta la cámara hacia el código QR. La detección es automática y se realiza localmente en tu navegador.
      </p>
    </div>
  )
}
